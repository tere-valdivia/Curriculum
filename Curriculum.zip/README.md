# curriculum
Personal curriculum
Done with the template made by Xavier Danaux (xdanaux@gmail.com) "ModernCV" Version 1.1
